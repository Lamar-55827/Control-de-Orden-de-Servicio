"""Configuración del sistema Dryg Tools."""
