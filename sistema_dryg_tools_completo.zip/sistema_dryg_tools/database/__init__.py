"""Capa de acceso a datos del sistema Dryg Tools."""
