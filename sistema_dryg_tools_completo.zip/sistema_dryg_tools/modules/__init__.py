"""Módulos de interfaz del sistema Dryg Tools."""
